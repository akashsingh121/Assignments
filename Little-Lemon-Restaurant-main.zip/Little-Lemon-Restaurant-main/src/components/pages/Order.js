import Heading from "../sections/orderPages/Heading";

export default function Order() {
  return (
    <>
      <Heading />
    </>
  );
}
